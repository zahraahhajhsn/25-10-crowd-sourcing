
<?php
Route::get('/', function () {
    return view('main');
});
Route::get('/login','participantlogincontroller@store');
Route::post('/psignup',"participantsignupcontroller@signup");
Route::post('/mpsignup',"participantsignupcontroller@index");
Route::post('/plogin',"participantlogincontroller@login");
Route::post('/mplogin',"participantlogincontroller@index");
Route::get('/signupp',"participantsignupcontroller@index");
Route::get('/loginp',"participantlogincontroller@index");

Route::get('/key',"keycontroller@index");
Route::post('/key',"keycontroller@checkkey");

Route::get('/answer',"answercontroller@index");
Route::post('/answersubmit',"answercontroller@submitanswer");
Route::post('/rate1',"answercontroller@gotorate");

Route::post('/displayanswers',"displaycontroller@index");
Route::get('/display',"displaycontroller@index");

Route::post('/display',"keyfcontroller@addworkshop");
Route::post('/displayk',"keyfcontroller@checkkey");
Route::get('/keyf',"keyfcontroller@index");

Route::post('/next',"sendratecontroller@index");
Route::post('/refresh',"sendratecontroller@showresults");
Route::get('/refreshg',"sendratecontroller@showresults");
Route::post('/nextround',"sendratecontroller@nextround");
Route::post('/gotoresult',"sendratecontroller@gotoresult");

Route::post('/showrate',"ratingcontroller@display");
Route::get('/rate',"ratingcontroller@index");
Route::post('/submitrate',"ratingcontroller@submitrate");


Route::post('/admin',"admincontroller@index");
Route::get('/admin1',"admincontroller@index");
Route::get('/request',"admincontroller@index1");
Route::post('/adminlogin',"admincontroller@login");
Route::post('/submitrequests',"admincontroller@submitrequests");

Route::get('/result',"ratingresultcontroller@index");
Route::post('/showresult',"ratingresultcontroller@showresult");

Route::post('/logout',"admincontroller@logout");

Route::post('/fsignup',"facilitatorsignupcontroller@signup");
Route::post('/mfsignup',"facilitatorsignupcontroller@index");
Route::post('/flogin',"facilitatorlogincontroller@login");
Route::post('/mflogin',"facilitatorlogincontroller@index");
Route::get('/signupf',"facilitatorsignupcontroller@index");
Route::get('/loginf',"facilitatorlogincontroller@index");

