<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;

class answercontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('answer');
    }

    public function submitanswer(Request $request)
    {
        $request->validate([
        'answer'=>"required",
         ]);
        $answer=$request->get('answer');
        $key=$request->session()->get('key');
        $participant=$request->session()->get('pemail');
        $participantn=DB::table('workshop')->where(['key'=>$key])->get('participantsnb');
        foreach($participantn as $t){
            $request->session()->put('nparticipant',$t->participantsnb);}
        $participantnb=$request->session()->get('nparticipant');
        $data=array('answer'=>$answer,'key'=>$key,'participant'=>$participant);
        $d=array('participant'=>$participant,'key'=>$key);
        $info=DB::table('answer')->where(['key'=>$key,'participant'=>$participant])->get();
        $a=DB::table('answer')->where(['key'=>$key])->get();
        if(count($a)>=$participantnb) {
            redirect()->back()->withErrors('OOPS!workshop is full.')->withInput();
            return redirect('answer');
        }
        elseif(count($info)>0){
            redirect()->back()->withErrors('multiple answers are prohibited!')->withInput();
            return redirect('answer');
        }
        
        else{
        try{
            DB::table('answer')->insertGetId($data);
            DB::table('rounds')->insert($d);
            redirect()->back()->withErrors('Thank you! Your answer have been submitted, please click on rating button to go to rating page.')->withInput();
            return redirect('answer');
        }catch (\Illuminate\Database\QueryException $e) {
        redirect()->back()->withErrors('invalid! Retry.')->withInput();
        return redirect('answer');

     }
}
    }

    public function gotorate(request $request)
    {
        $n=$request->session()->get('nparticipant');
        $key=$request->session()->get('key');
        $participant=$request->session()->get('pemail');
        $d="";
        $b=DB::table('answer')->where(['key'=>$key])->get();
        $c=count($b);
        
        $info=DB::table('answer')->where(['key'=>$key,'participant'=>$participant])->get();
        if($c==$n && count($info)>0){
            $answers=array();$request->session()->put('answers',$answers);
            $round=1;
            
            $request->session()->put('round',$round);
            return view('rate',['a'=>$d]);
        }
        elseif($c!=$n && count($info)<=0){
            redirect()->back()->withErrors('you have not answered yet! please answer then go to rate')->withInput();
            return redirect('answer');
        }  
        else{
            redirect()->back()->withErrors('please wait other participants to answer to go to rate!')->withInput();
            return redirect('answer');}

        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
