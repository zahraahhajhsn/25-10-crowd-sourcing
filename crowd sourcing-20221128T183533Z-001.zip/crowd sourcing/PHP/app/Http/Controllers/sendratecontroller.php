<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class sendratecontroller extends Controller
{
    public function index(request $request)
    {
        $key=$request->session()->get('key');
        $a=DB::table('answer')->where(['key'=>$key])->get();
        $c=count($a);
        $n=$request->session()->get('nparticipant');
        if($c==$n){
          $round=1;
          $request->session()->put('round',$round);
          return view('ratingf',['a'=>[],'r'=>[],'p'=>[],'round'=>$round,'n'=>0]);
        }
        else{
            return redirect('display');}
    }

    public function showresults(Request $request)
    {
        $key=$request->session()->get('key');
        $info=DB::table('rated')->where(['key'=>$key])->get();
        $d=DB::table('answer')->where(['key'=>$key])->get();
        $round=$request->session()->get('round');
        $answer=[];
        $rate=[];
        $p=[];
        $e='There are participants whom did not rate yet!';
        $m='All participants had submitted their rates, Please press the (next round) button to begin another round!';
        $f='All rates have been submitted.Please press the (result) button to view final results';
        if(count($d)!=count($info)){
            for($i=0;$i<count($info);$i++){
                $a=DB::table('answer')->where(['id'=>$info[$i]->answerid,'key'=>$key])->get('answer');
                array_push($answer,$a[0]);
                array_push($rate,$info[$i]->rate);
                array_push($p,$info[$i]->participant);
            }
            $request->session()->put('message',$e);   
            return view('ratingf',['a'=>$answer,'r'=>$rate,'p'=>$p,'round'=>$round,'n'=>count($d)]);
        }
        
        elseif(count($d)==count($info) && $round!=5){
            for($i=0;$i<count($info);$i++){
                $a=DB::table('answer')->where(['id'=>$info[$i]->answerid,'key'=>$key])->get('answer');
                print_r($a);
                array_push($answer,$a[0]);
                array_push($rate,$info[$i]->rate);
                array_push($p,$info[$i]->participant);
            }
            $request->session()->put('message',$m);
            return view('ratingf',['a'=>$answer,'r'=>$rate,'p'=>$p,'round'=>$round,'n'=>count($d)]);}
        else{
            for($i=0;$i<count($info);$i++){
                $a=DB::table('answer')->where(['id'=>$info[$i]->answerid,'key'=>$key])->get('answer');
                array_push($answer,$a[0]);
                array_push($rate,$info[$i]->rate);
                array_push($p,$info[$i]->participant);
            }
            $request->session()->put('message',$f); 
            return view('ratingf',['a'=>$answer,'r'=>$rate,'p'=>$p,'round'=>$round,'n'=>count($d)]);
            

        }
         
       
    }

    public function nextround(request $request)
    {
    $key=$request->session()->get('key');
    $info=DB::table('rated')->where(['key'=>$key])->get();
    $d=DB::table('answer')->where(['key'=>$key])->get();
    $round=$request->session()->get('round');
    if(count($d)==count($info) && $round!=5){
        DB::table('rated')->delete();
        $round=5;
        $request->session()->put('round',$round); 
            return redirect('refreshg'); }
    else{
        return redirect('refreshg');
    }           
    }

    public function gotoresult(request $request)
    {   
        $key=$request->session()->get('key');
        $info=DB::table('rated')->where(['key'=>$key])->get();
        $d=DB::table('answer')->where(['key'=>$key])->get();
        $round=$request->session()->get('round');
        if(count($d)==count($info) && $round==5){
            return redirect('result');
        }else{
                return redirect('refreshg');
        
    }
}

    
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
