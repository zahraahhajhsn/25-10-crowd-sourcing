<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class admincontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         return view('adminlogin');
    }
    public function index1()
    {
       
        $info=DB::table('pending')->get();
        return view('requests',['a'=>$info]);
    }

    public function login(Request $request)
    {
        $request->validate([
            'email'=>'required|email|',
            'password'=>'required|min:5'
             ]);
            $email = $request->get('email');
            $password = $request->get('password');
            $data=array("email"=>$email,"password"=>$password);
            $info=DB::table('admin')->where(['email'=>$email,'password'=>$password])->get();
            if(count($info)>0) {
                return redirect('request');}
            else{
                back()->withErrors(["wrong email address or password!"]);
                return view('adminlogin');
            }
    }
    public function submitrequests(Request $request)
    {  
        $info=DB::table('pending')->get();
        for($i=0;$i<count($info);$i++){
            if( $_POST[$i]){
                try{
                    if($info[$i]->type == 'facilitator'){
                        $data=array('fname'=>$info[$i]->name,"femail"=>$info[$i]->email,"fpassword"=>$info[$i]->password,"ftelephone"=>$info[$i]->telephone);
                        DB::table('facilitators')->insert($data);
                        DB::table('pending')->where(['email'=>$info[$i]->email])->delete();
                        $c= $info[$i]->email;
                        $c=$c.' is accepted successfully ';
                        $c=$c.' as a '.$info[$i]->type;
                        redirect()->back()->withErrors($c)->withInput();
                        return redirect('request');
                    }
                    else{
                        $data=array('name'=>$info[$i]->name,"email"=>$info[$i]->email,"password"=>$info[$i]->password,"telephone"=>$info[$i]->telephone);
                        DB::table('participants')->insert($data);
                        DB::table('pending')->where(['email'=>$info[$i]->email])->delete();
                    
                        $c= $info[$i]->email;
                        $c=$c.' is accepted successfully ';
                        $c=$c.' as a '.$info[$i]->type;
                        redirect()->back()->withErrors($c)->withInput();
                        return redirect('request');}
                 }catch (\Illuminate\Database\QueryException $e) {
                redirect()->back()->withErrors('invalid!')->withInput();
                return redirect('request');}

            break;
        }}
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function logout(Request $request)
    {
        return view('main');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
