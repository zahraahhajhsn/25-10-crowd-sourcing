<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class ratingcontroller extends Controller
{
    public function index()
    {
        $b="";
        return view('rate',['a'=>$b]);
    }

    public function display(Request $request)
    {   $round=$request->session()->get('round');
        $key=$request->session()->get('key');
        $p=$request->session()->get('pemail');
        $info=DB::table('rated')->where(['key'=>$key])->get('answerid');
        $info1=DB::table('rated')->where(['key'=>$key])->get('participant');
        $d=DB::table('answer')->where(['key'=>$key])->get();
        $q=DB::table('rounds')->where(['participant'=>$p,'key'=>$key])->get();
print_r($q[0]->$round);
print_r(count($info));
        if($q[0]-> $round ==0 && $round=1 && count($info)==0){
            $a=DB::table('answer')->where(['key'=>$key])->pluck('id');
                $c=$a[rand(0,count($a)-1)];
                $v=DB::table('answer')->where(['id'=>$c])->pluck('answer');
                $request->session()->put('id',$c);
                $b=$v[0];
                return view('rate',['a'=>$b]);
            }
            

        elseif( $q[0]-> $round ==0 && count($info)==0){
            for($l=1;$i<$round;$l++){
                for($i=0;$i<count($d);$l++){
                    if(($q[0]->$l)!=($d[$i]->id) && ($d[$i]->flag)<5 ){
                    $a=DB::table('answer')->where(['key'=>$key])->pluck('id');
                    $c=$a[rand(0,count($a)-1)];
                    $v=DB::table('answer')->where(['id'=>$c])->pluck('answer');
                    $request->session()->put('id',$c);
                    $b=$v[0];
                    return view('rate',['a'=>$b]);}}}}

        elseif( count($info)!=0 && $round==1 && $q[0]->$round==0){
            for($i=0;$i<count($info1);$i++){
                    if(($info1[$i]->participant)==$p){
                        redirect()->back()->withErrors('please wait till other participants submit their ratings!')->withInput();
                        return redirect('rate');}}  
            for($i=0;$i<count($info);$i++){ 
                for($j=0;$j<count($d);$j++){
                    if(($d[$i]->flag)<5  && ($d[$i]->id)!=($info[$j]->answerid)){
                        $a=DB::table('answer')->where(['id'=>($d[$i]->id)])->pluck('answer');
                        $b=$a[rand(0,count($a)-1)];
                        $request->session()->put('id',$d[$i]->id);
                        return view('rate',['a'=>$b]);   
                                   }}}}
        
        elseif( count($info)!=0 && $q[0]->$round==0){
            for($i=0;$i<count($info1);$i++){
                if(($info1[$i]->participant)==$p){
                    redirect()->back()->withErrors('please wait till other participants submit their ratings!')->withInput();
                    return redirect('rate');}}
           for($l=1;$i<$round;$l++){   
             for($i=0;$i<count($info);$i++){ 
                for($j=0;$j<count($d);$j++){
                     if(($q[0]->$l)!=($d[$i]->id) && ($d[$i]->flag)<5  && ($d[$i]->id)!=($info[$j]->answerid)){
                        $a=DB::table('answer')->where(['id'=>($d[$i]->id)])->pluck('answer');
                        $b=$a[rand(0,count($a)-1)];
                        $request->session()->put('id',$d[$i]->id);
                        return view('rate',['a'=>$b]);
                       }}}}}
        else{
            redirect()->back()->withErrors('please wait till other participants submit their ratings!')->withInput();
            return redirect('rate');
        }               
        }

    public function submitrate(Request $request){
        $id=$request->session()->get('id');
        $round=$request->session()->get('round');
        $key=$request->session()->get('key');
        $p=$request->session()->get('pemail');
        $r=$request->get('rating');
        $b=DB::table('rated')->where(['answerid'=>$id],['participant'=>$p])->get();
        if(count($b)>0){
            redirect()->back()->withErrors('you have already rated.please wait till other participants submit their ratings!')->withInput();
            return redirect('rate');
        }
        else{
            $data=array('answerid'=>$id,"key"=>$key,"participant"=>$p,"rate"=>$r);
             try{
                DB::table('answer')->where(['id'=>$id])->increment('rate',($r/5));
                DB::table('answer')->where(['id'=>$id])->increment('flag',1);
                DB::table('rated')->insert($data);
                DB::table('rounds')->where(['participant'=>$p,'key'=>$key])->update([$round => $id]);
                redirect()->back()->withErrors('Thank you for rating.please wait till other participants submit their ratings!')->withInput();
                return redirect('rate');
 
            }catch (\Illuminate\Database\QueryException $e) {
                redirect()->back()->withErrors('Rating field is required!')->withInput();
                return redirect('rate');


        }
    }
    
        
        
    }


    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
    
    }
     
    public function destroy($id)
    {
        //
    }
}
