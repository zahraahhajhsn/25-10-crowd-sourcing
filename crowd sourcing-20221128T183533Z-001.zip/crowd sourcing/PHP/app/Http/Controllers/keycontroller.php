<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class keycontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(request $request)
    {    
       $e=$request->cookie('name');
        print( $e);
        return view('key');
    }
   
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function checkkey(Request $request)
    {
            $request->validate([
            'key'=>"required|min:10",
             ]);
            $key=$request->get('key');
           
            $info=DB::table('workshop')->where(['key'=>$key])->get();
            if(count($info)>0) {
                $name= DB::table('workshop')->where(['key'=>$key])->get('name');
                foreach($name as $t){
                $request->session()->put('workshopname',$t->name);}
             $request->session()->put('key',$key);
             $question=DB::table('workshop')->where(['key'=>$key])->get('question');
             foreach($question as $t){
                $request->session()->put('question',$t->question);}
                return redirect('answer');}
            else{ 
               back()->withErrors(["wrong key!"]);
               return redirect('key');
            }    
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
