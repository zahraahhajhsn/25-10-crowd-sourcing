<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class ratingresultcontroller extends Controller
{
    
    public function index()
    {
        return view('result',['a'=>[]]);
    }

    public function create()
    {
        //
    }

    public function showresult(Request $request)
    {
        $key=$request->session()->get('key');
        $n=$request->session()->get('nparticipant');
        $request->validate([
            'result'=>"required|lte:$n"
            ]);
        $b=$request->get('result');      
        try{
           
        $a=DB::table('answer')->where(['key'=>$key])->orderBy('rate','desc')->take($b)->get();
        return view('result',['a'=>$a]);
    }  catch (\Illuminate\Database\QueryException $e) {
        redirect()->back()->withErrors('invalid input!')->withInput();
        return redirect('result');
    }

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
