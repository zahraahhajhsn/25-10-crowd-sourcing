<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class keyfcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        return view('createworkshop');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function checkkey(Request $request)
    {
       
        $request->validate([
            'key'=>"required|min:10"]);
        
        $key=$request->get('key');
        $email=$request->session()->get('femail');
        $info=DB::table('workshop')->where(['facilitator'=>$email,'key'=>$key])->get();
            if(count($info)>0) {
                $request->session()->put('key',$key);
                $participantn=DB::table('workshop')->where(['key'=>$key])->get('participantsnb');
                foreach($participantn as $t){
                $request->session()->put('nparticipant',$t->participantsnb);}
                return redirect('display');}
            else{
                back()->withErrors(["wrong key or Access denied!"]);
               return redirect('keyf');
            }    
    
    }
    public function addworkshop(Request $request)
    {
        $request->validate([
            'wname'=>"required",
            'wquestion'=>"required",
            'nparticipants'=>"required"
             ]);
            $name = $request->get('wname');
            $question = $request->get('wquestion');
            $facilitator=$request->session()->get('femail');
            $nparticipants=$request->get('nparticipants');
            $key="";
            for($i=0;$i<10;$i++){ 
                $key.=rand(0,10);}
            $data=array('name'=>$name,"key"=>$key,"question"=>$question,"facilitator"=>$facilitator,"participantsnb"=>$nparticipants);
        try{
           DB::table('workshop')->insert($data);
           $request->session()->put('workshopname',$name);
           $request->session()->put('question',$question);
           $request->session()->put('nparticipant',$nparticipants);
           $request->session()->put('key',$key);
           
               return redirect('display');
        }catch (\Illuminate\Database\QueryException $e) {
            
               redirect()->back()->withErrors('invalid! Retry.')->withInput();
               return redirect('keyf');
            }
        }       
    

    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
