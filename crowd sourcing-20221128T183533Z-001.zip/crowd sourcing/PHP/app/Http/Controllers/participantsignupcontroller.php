<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\participant;
use DB;
class participantsignupcontroller extends Controller
{
    
    public function index()
    {
        return view('participantsignup');
    }
    public function create()
    {
        
    }

    public function signup(Request $request)
    {

      
        $request->validate([
        'name'=>"required",
        'email'=>"required|email|",
        'password'=>"required|min:5",
        'telephone'=> "required"
         ]);
        $name = $request->get('name');
        $email = $request->get('email');
        $password = $request->get('password');
        $telephone = $request->get('telephone');
        $data=array('name'=>$name,"email"=>$email,"password"=>$password,"telephone"=>$telephone,"type"=>'participant',"date"=>date('Y-m-m'));
        print_r($data);
    try{
        DB::table('pending')->insert($data);
           $request->session()->put('pemail',$email);
           $request->session()->put('pname',$name);
           
           redirect()->back()->withErrors('please wait for the comfirmation of admin')->withInput();
           return redirect('loginp');
    }  catch (\Illuminate\Database\QueryException $e) {
        redirect()->back()->withErrors('invalid email address!')->withInput();
        return redirect('signupp');
    }

    
    }

    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
