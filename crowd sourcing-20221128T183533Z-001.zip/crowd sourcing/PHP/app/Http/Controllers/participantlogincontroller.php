<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;

class participantlogincontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('participantlogin');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }


    public function login(Request $request)
    {
            $request->validate([
                'email'=>"required|email|",
            'password'=>"required|min:5"
             ]);
            $email = $request->get('email');
            $password = $request->get('password');
           
            $data=array("email"=>$email,"password"=>$password);
            try{
                $info=DB::table('participants')->where(['email'=>$email,'password'=>$password])->get();
               if(count($info)>0) {
                $name=DB::table('participants')->where(['email'=>$email,'password'=>$password])->get('name');
                $request->session()->put('pemail',$email);
                foreach($name as $t){
                    $request->session()->put('pname',$t->name);}
                return redirect('key');}
            else{
                $i=DB::table('pending')->where(['email'=>$email,'password'=>$password,'type'=>'participant'])->get();
                if(count($i)>0){
                    back()->withErrors("your request is still pending")->withInput();
               return redirect('loginp');
            }
                else{back()->withErrors(["wrong email address or password!"]);
               return redirect('loginp');}
            }
        }  catch (\Illuminate\Database\QueryException $e) {
            redirect()->back()->withErrors('invalid email address!')->withInput();
            return redirect('signupf');
        }

    }

    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
