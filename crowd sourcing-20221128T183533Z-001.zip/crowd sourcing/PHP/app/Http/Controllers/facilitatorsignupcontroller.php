<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class facilitatorsignupcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('facilitatorsignup');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function signup(Request $request)
    {
        $request->validate([
            'name'=>"required",
            'email'=>"required|email|",
            'password'=>"required|min:5",
            'telephone'=> "required"
             ]);
            $name = $request->get('name');
            $email = $request->get('email');
            $password = $request->get('password');
            $telephone = $request->get('telephone');
            $data=array('name'=>$name,"email"=>$email,"password"=>$password,"telephone"=>$telephone,"type"=>'facilitator',"date"=>date('Y-m-m'));
        
        try{
           DB::table('pending')->insert($data);
           $request->session()->put('femail',$email);
           $request->session()->put('fname',$name);
           redirect()->back()->withErrors('please wait for the comfirmation of admin')->withInput();
           return redirect('loginf');
        }  catch (\Illuminate\Database\QueryException $e) {
            redirect()->back()->withErrors('invalid email address!')->withInput();
            return redirect('signupf');
        }
    
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
