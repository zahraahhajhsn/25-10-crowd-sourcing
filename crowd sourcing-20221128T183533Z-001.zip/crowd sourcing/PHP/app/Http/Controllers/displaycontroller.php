<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\answer;
class displaycontroller extends Controller
{
   
    public function index(request $request)
    {   $key=$request->session()->get('key');
        $a=DB::table('answer')->where(['key'=>$key])->get();
        $c=count($a);
        $n=$request->session()->get('nparticipant');
        $m='All participants had submitted answers, Please press the (next page) button to view rates!';
        $e='There are participants whom did not answer yet!';
        if($c==$n){$request->session()->put('attempts',$m);}
        else{
            $request->session()->put('attempts',$e);}
        return view('display',['a'=>$a,'n'=>$n]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showdata(request $request)
    {
        
    
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
