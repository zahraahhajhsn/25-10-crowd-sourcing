<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
        'mflogin' , 'mplogin','plogin','rate1','displayk','flogin','display','displayanswers','next','loginf',
        'rate2','answersubmit','key','ratee','showrate','submitrate','refresh','nextround','gotoresult','showresult','answersubmit'
         ,'logout','submitrequests'
    ];
}
