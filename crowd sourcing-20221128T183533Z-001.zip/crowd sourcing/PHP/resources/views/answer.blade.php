<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:left; font-size:50px">Hello {{ Session::get('pname')}}!</h1>
<h1 style="text-align:center;font-size:40px">Welcome to {{ Session::get('workshopname')}} workshop</h1> 
@foreach($errors ->all() as $error)
<li  style="color:red;text-align:center;font-size:20px">{{$error}}</li>
@endforeach
   <form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="{{URL::to('/answersubmit')}}">
   @csrf
        Please enter your suggestion or answer for the following question:<br><br>
        <strong>{{Session::get('question')}}</strong><br><br>
       <input type="text" name='answer' size="100" class="form-control">
       <br><br>
       <input type="submit" name='confirm' value="submit" size="20">
       <br>
       </form>
       <form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="{{URL::to('/rate1')}}">  
       <input type="submit" name='rating' value="rating" size="20">
       <br>
       </form>

</html>