<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:left; font-size:50px">Hello {{ Session::get('fname')}}!</h1>
<h2 style="text-align:center;font-size:40px">Welcome to {{ Session::get('workshopname')}} workshop with key:<lh2> 
<h2 style="text-align:center;font-size:40px"><strong>{{ Session::get('key')}} </strong> </h2>
<h2 style="text-align:center;font-size:20px"> please make sure to distribute to participants</h2>

<form  style="text-align:center;font-size:20px" method="post" action="{{URL::to('/displayanswers')}}">
<input type="submit" name='refresh answers' value="refresh answers"  size="20">
@if(count($a)!=0)  
<p style="color:red;text-align:center;font-size:20px">{{Session::get('attempts')}}</p>
<p style="text-align:center;font-size:20px;font-family:verdana;color:white">Answers of question: {{Session::get('question')}}</p>

       <table border="1" style="text-align:center;font-size:20px;font-family:verdana;color:white;background-color:black" align="center">   
       <tr style="color:gray"><th><strong>PARTICIPANT</strong></th><th><strong>ANSWER</strong></th>
       </tr>
       @foreach($a as $data)
       <tr>
      <th>{{$data->participant}}</th>
      <th>{{$data->answer}}</th>
      </tr>
       @endforeach
       </table>
@endif
@if(count($a)==$n)
</form>
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="{{URL::to('/next')}}">
<input type="submit" name='shuffle' value="next page" size="20">
</form>  
@endif
</html>