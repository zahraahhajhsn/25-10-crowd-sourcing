<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:left; font-size:50px">Hello {{ Session::get('fname')}}!</h1>
<h2 style="text-align:center;font-size:40px">Welcome to {{ Session::get('workshopname')}} workshop </h2>
@foreach($errors->all() as $error)
<p  style="color:red;text-align:center;font-size:20px">{{$error}}</p>
@endforeach
<form  style="text-align:center;font-size:20px" method="post" action="{{URL::to('showresult')}}">
please enter number of wanted answers:
<input type="text" name='result'  size="20">
<input type="submit" name='number' value="submit"  size="20">
@if(count($a)!=0)
 <h2 style="text-align:center;font-size:35px">List of most rated questions</h2>
       <table border="1" style="text-align:center;font-size:20px;font-family:verdana;color:white;background-color:black" align="center">
       <tr style="color:gray"><th><strong>RANK</strong></th><th><strong>ANSWER</strong></th><th><strong>RATE</strong></th><th><strong>SUGGESTED BY</strong></th>
       </tr>
    @for($i=0; $i< count($a);$i++)
      <tr>
      <th>{{$i+1}}</th>
      <th>{{$a[$i]->answer}}</th>
      <th>{{$a[$i]->rate}}/5</th>
      <th>{{$a[$i]->participant}}</th>
      </tr>
      @endfor
      </table>
    @endif  
</form>
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="{{URL::to('/logout')}}">
<input type="submit" name='logout' value="logout" size="20">
</form>