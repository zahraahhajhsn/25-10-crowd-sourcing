
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 

<h1 style="text-align:center;font-size:70px;font-family:georgia;font-weight=bold">LogIn as Participant</h1> 
@foreach($errors ->all() as $error)
<li  style="color:red;text-align:center;font-size:20px">{{$error}}</li>
@endforeach
   <form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="{{URL::to('/plogin')}}">
   @csrf
       <br> Enter email address:<br>
       <input type="email" name='email' size="30"class="form-control">
       <br> Enter password:<br>
       <input type="password" name='password' size="30"class="form-control" >
       <br><br>
       <input type="submit" name='login' value="login" size="20">
       <br>
       </form>
   <br>
   <form style="text-align:center;font-size:20px;font-family:verdana;font-weight=bold">
   <font color="white">new user?</font><a href="signupp">signup</a>
      </form>
    </body>
</html>
