<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:center;font-size:70px;font-family:georgia;font-weight=bold">WELCOME!<h1>
<br>
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="{{URL::to('/mplogin')}}">
   @csrf
       <style>
  .button {
  background-color: grey;
  border: none;
  color: white;
  padding: 40px 60px;
  align:center;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 18px;
  margin: 10px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
  font-family:verdana;
}
  .button1:hover {
  background-color: grey;
  color: white;
  border: 2px solid #e7e7e7;}
</style>
<button class="button button1">Login as Participant</button>
</form>    
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="{{URL::to('/mflogin')}}">
   @csrf 
   <style>
   .button1:hover {
  background-color: grey;
  color: white;
  border: 2px solid #e7e7e7;}
</style>
<button class="button button1">Login as Facilitator</button>
</form> 
<br>
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="{{URL::to('/admin')}}">
   @csrf 
   <style>
   .button1:hover {
  background-color: grey;
  color: white;
  border: 2px solid #e7e7e7;}
</style>
<button class="button button1">Login as Admin</button>
</form>       
</body>
</html>