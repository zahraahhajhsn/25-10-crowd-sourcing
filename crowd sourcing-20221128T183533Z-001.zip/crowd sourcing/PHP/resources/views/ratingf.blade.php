<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:left; font-size:50px">Hello {{ Session::get('fname')}}!</h1>
<h2 style="text-align:center;font-size:40px">Welcome to {{ Session::get('workshopname')}} workshop <lh2>
<p style="color:red;text-align:center;font-size:15px">Make sure to press refresh button everywhile for rating updates</p>
<form  style="text-align:center;font-size:20px" method="post" action="{{URL::to('/refresh')}}">
<input type="submit" name='refresh answers' value="refresh answers"  size="20">
<p style="text-align:center;font-size:20px;font-family:verdana;color:white">Round {{Session::get('round')}}</p>

<p style="color:red;text-align:center;font-size:20px">{{Session::get('message')}}</p>
@if(count($a)!=0)
<p style="text-align:center;font-size:20px;font-family:verdana;color:white">Ratings of answers of question: {{Session::get('question')}}</p>
    
      <table border="1" style="text-align:center;font-size:20px;font-family:verdana;color:white;background-color:black" align="center">
      <tr style="color:gray"><th><strong>ANSWER</strong></th><th><strong>RATE</strong></th><th><strong>RATED BY</strong></th>
       </tr>
    @for($i=0; $i < count($a);$i++)
       <tr>
      <th>{{$a[$i]->answer}}</th>
      <th>{{$r[$i]}}/5</th>
      <th>{{$p[$i]}}</th>
      </tr>
    @endfor
      </table>
</form>
@endif
@if(count($a)==$n)
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="{{URL::to('/nextround')}}">
<input type="submit" name='shuffle' value="next round" size="20">
</form>
@endif
<br>
@if($round== 5)
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="{{URL::to('/gotoresult')}}">
<input type="submit" name='shuffle' value="final result" size="20">
</form>
@endif  
</html>