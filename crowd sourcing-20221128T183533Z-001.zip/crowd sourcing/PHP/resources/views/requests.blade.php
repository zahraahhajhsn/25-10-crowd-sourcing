<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:left; font-size:50px">Hello Admin</h1>
@foreach($errors->all() as $error)
<p  style="color:red;text-align:center;font-size:20px">{{$error}}</p>
@endforeach
<form  style="text-align:center;font-size:20px" method="post" action="{{URL::to('/submitrequests')}}">
@if(count($a)!=0)
<h2 style="text-align:center;font-size:30px">There are {{count($a)}} pending requests</h2><br>
<table border="1" style="text-align:center;font-size:20px;font-family:verdana;color:white;background-color:black" align="center">
      <tr style="color:gray"><th><strong>EMAIL</strong></th><th><strong>TYPE</strong></th><th><strong>PENDING SINCE</strong></th>
       </tr>
    @for($i=0; $i < count($a);$i++)
       <tr>
      <th>{{$a[$i]->email}}</th>
      <th>{{$a[$i]->type}}</th>
      <th>{{$a[$i]->date}}</th>
      <th><input type="submit" name= {{$i}} value="accept" size="20"></th>
      </tr>
    @endfor
      </table>
@else
<h2 style="text-align:center;font-size:30px">There are no pending requests</h2>
@endif
</form>
<br>
<form  style="text-align:center;font-size:20px" method="post" action="{{URL::to('/logout')}}">
<input type="submit" name='logout' value="logout"  size="20">
</form>