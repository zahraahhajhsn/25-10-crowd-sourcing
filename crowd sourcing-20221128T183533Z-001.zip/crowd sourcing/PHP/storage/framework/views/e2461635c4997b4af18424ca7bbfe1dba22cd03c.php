<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 

<h1 style="text-align:center;font-size:70px;font-family:georgia;font-weight=bold">Sign Up as Participant</h1> 
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li  style="color:red;text-align:center;font-size:20px"><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="<?php echo e(URL::to('/psignup')); ?>">
    <?php echo csrf_field(); ?>
       Enter name:<br>
       <input type="text" name='name' size="30" class="form-control" >
       <br> Enter email address:<br>
       <input type="email" name='email' size="30"class="form-control">
       <br> Enter password:<br>
       <input type="password" name='password' size="30"class="form-control">
       <br>Enter telephone number:<br>
       <input type="tel" name='telephone' size="30"class="form-control">
       <br><br>
       <input type="submit" name='signup' value="submit" size="20">
       <br>
       </form>
  </body>     
</html><?php /**PATH C:\wamp64\www\PHP\resources\views/participantsignup.blade.php ENDPATH**/ ?>