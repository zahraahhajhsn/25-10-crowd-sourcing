<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:left; font-size:50px">Hello <?php echo e(Session::get('fname')); ?>!</h1>
<h2 style="text-align:center;font-size:40px">Welcome to <?php echo e(Session::get('workshopname')); ?> workshop <lh2>
<p style="color:red;text-align:center;font-size:15px">Make sure to press refresh button everywhile for rating updates</p>
<form  style="text-align:center;font-size:20px" method="post" action="<?php echo e(URL::to('/refresh')); ?>">
<input type="submit" name='refresh answers' value="refresh answers"  size="20">
<p style="text-align:center;font-size:20px;font-family:verdana;color:white">Round <?php echo e(Session::get('round')); ?></p>

<p style="color:red;text-align:center;font-size:20px"><?php echo e(Session::get('message')); ?></p>
<?php if(count($a)!=0): ?>
<p style="text-align:center;font-size:20px;font-family:verdana;color:white">Ratings of answers of question: <?php echo e(Session::get('question')); ?></p>
    
      <table border="1" style="text-align:center;font-size:20px;font-family:verdana;color:white;background-color:black" align="center">
      <tr style="color:gray"><th><strong>ANSWER</strong></th><th><strong>RATE</strong></th><th><strong>RATED BY</strong></th>
       </tr>
    <?php for($i=0; $i < count($a);$i++): ?>
       <tr>
      <th><?php echo e($a[$i]->answer); ?></th>
      <th><?php echo e($r[$i]); ?>/5</th>
      <th><?php echo e($p[$i]); ?></th>
      </tr>
    <?php endfor; ?>
      </table>
</form>
<?php endif; ?>
<?php if(count($a)==$n): ?>
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="<?php echo e(URL::to('/nextround')); ?>">
<input type="submit" name='shuffle' value="next round" size="20">
</form>
<?php endif; ?>
<br>
<?php if($round== 5): ?>
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="<?php echo e(URL::to('/gotoresult')); ?>">
<input type="submit" name='shuffle' value="final result" size="20">
</form>
<?php endif; ?>  
</html><?php /**PATH C:\wamp64\www\PHP\resources\views/ratingf.blade.php ENDPATH**/ ?>