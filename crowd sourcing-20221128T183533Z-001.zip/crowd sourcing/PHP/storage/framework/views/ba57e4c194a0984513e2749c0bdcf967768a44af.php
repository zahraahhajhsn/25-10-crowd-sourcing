<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:left; font-size:50px">Hello <?php echo e(Session::get('fname')); ?>!</h1>
<h2 style="text-align:center;font-size:40px">Welcome to <?php echo e(Session::get('workshopname')); ?> workshop </h2>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p  style="color:red;text-align:center;font-size:20px"><?php echo e($error); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<form  style="text-align:center;font-size:20px" method="post" action="<?php echo e(URL::to('showresult')); ?>">
please enter number of wanted answers:
<input type="text" name='result'  size="20">
<input type="submit" name='number' value="submit"  size="20">
<?php if(count($a)!=0): ?>
 <h2 style="text-align:center;font-size:35px">List of most rated questions</h2>
       <table border="1" style="text-align:center;font-size:20px;font-family:verdana;color:white;background-color:black" align="center">
       <tr style="color:gray"><th><strong>RANK</strong></th><th><strong>ANSWER</strong></th><th><strong>RATE</strong></th><th><strong>SUGGESTED BY</strong></th>
       </tr>
    <?php for($i=0; $i< count($a);$i++): ?>
      <tr>
      <th><?php echo e($i+1); ?></th>
      <th><?php echo e($a[$i]->answer); ?></th>
      <th><?php echo e($a[$i]->rate); ?>/5</th>
      <th><?php echo e($a[$i]->participant); ?></th>
      </tr>
      <?php endfor; ?>
      </table>
    <?php endif; ?>  
</form>
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="<?php echo e(URL::to('/logout')); ?>">
<input type="submit" name='logout' value="logout" size="20">
</form><?php /**PATH C:\wamp64\www\PHP\resources\views/result.blade.php ENDPATH**/ ?>