<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:left; font-size:50px">Hello <?php echo e(Session::get('pname')); ?>!</h1>
<h1 style="text-align:center;font-size:60px">Key of Workshop</h1> 
<?php $__currentLoopData = $errors ->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li  style="color:red;text-align:center;font-size:20px"><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="<?php echo e(URL::to('/key')); ?>">
   <?php echo csrf_field(); ?>
       Enter key:<br>
       <input type="text" name='key' size="30" class="form-control">
       <br><br>
       <input type="submit" name='confirmkey' value="submit" size="20">
       <br>
       </form>
    
</html><?php /**PATH C:\wamp64\www\PHP\resources\views/key.blade.php ENDPATH**/ ?>