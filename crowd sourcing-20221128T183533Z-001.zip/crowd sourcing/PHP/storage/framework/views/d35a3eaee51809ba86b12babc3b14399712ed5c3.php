<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:left; font-size:50px">Hello Admin</h1>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p  style="color:red;text-align:center;font-size:20px"><?php echo e($error); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<form  style="text-align:center;font-size:20px" method="post" action="<?php echo e(URL::to('/submitrequests')); ?>">
<?php if(count($a)!=0): ?>
<h2 style="text-align:center;font-size:30px">There are <?php echo e(count($a)); ?> pending requests</h2><br>
<table border="1" style="text-align:center;font-size:20px;font-family:verdana;color:white;background-color:black" align="center">
      <tr style="color:gray"><th><strong>EMAIL</strong></th><th><strong>TYPE</strong></th><th><strong>PENDING SINCE</strong></th>
       </tr>
    <?php for($i=0; $i < count($a);$i++): ?>
       <tr>
      <th><?php echo e($a[$i]->email); ?></th>
      <th><?php echo e($a[$i]->type); ?></th>
      <th><?php echo e($a[$i]->date); ?></th>
      <th><input type="submit" name= <?php echo e($i); ?> value="accept" size="20"></th>
      </tr>
    <?php endfor; ?>
      </table>
<?php else: ?>
<h2 style="text-align:center;font-size:30px">There are no pending requests</h2>
<?php endif; ?>
</form>
<br>
<form  style="text-align:center;font-size:20px" method="post" action="<?php echo e(URL::to('/logout')); ?>">
<input type="submit" name='logout' value="logout"  size="20">
</form><?php /**PATH C:\wamp64\www\PHP\resources\views/requests.blade.php ENDPATH**/ ?>