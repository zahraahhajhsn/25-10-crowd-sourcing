<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style ="background:url(https://spin.atomicobject.com/wp-content/uploads/iteration-meeting.jpg); 
background-size:cover"> 
<h1 style="text-align:left; font-size:50px">Hello <?php echo e(Session::get('pname')); ?>!</h1>
<h2 style="text-align:center;font-size:40px">Welcome to <?php echo e(Session::get('workshopname')); ?> workshop <lh2>
<p style="color:red;text-align:center;font-size:20px">Please note that you can't rate another answer before the submission of all participants' rating!</p>
<p style="color:red;text-align:center;font-size:15px">Make sure to press refresh button everywhile for updates</p>
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="<?php echo e(URL::to('/showrate')); ?>">
<input type="submit" name='shuffle' value="refresh" size="20">
</form>  
<p style="text-align:center;font-size:20px;font-family:verdana;color:white">Round <?php echo e(Session::get('round')); ?></p>
<form  style="text-align:center;font-size:20px;font-family:verdana" method="post" action="<?php echo e(URL::to('/submitrate')); ?>">

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p  style="color:red;text-align:center;font-size:20px"><?php echo e($error); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if($a!=''): ?>
<p style="text-align:center;font-size:20px;font-family:verdana;color:white">Answer of question: <?php echo e(Session::get('question')); ?></p>
<table border="1" style="text-align:center;font-size:20px;font-family:verdana;color:white;background-color:black" align="center">
       <tr style="color:gray"><th><strong>answer</strong></th><th><strong>rate</strong></th>
       </tr>
       <tr>
      <th><?php echo e($a); ?></th>
      <th><input type="radio" name='rating' value="1" id=1><lable for="1"required>1</lable>
      <input type="radio" name='rating' value="2" id=2><lable for="2" required>2</lable>
      <input type="radio" name='rating' value="3" id=3><lable for="3"required>3</lable>
      <input type="radio" name='rating' value="4" id=4><lable for="4"required>4</lable>
      <input type="radio" name='rating' value="5" id=5><lable for="5"required>5</lable></th>
      </tr>
       </table>
       <br>
<input type="submit" name='shuffle' value="submit rate" size="20">
</form>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\PHP\resources\views/rate.blade.php ENDPATH**/ ?>