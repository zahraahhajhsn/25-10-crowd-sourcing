

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`email`)
) ;

--

-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
CREATE TABLE IF NOT EXISTS `answer` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `answer` text NOT NULL,
  `participant` varchar(30) NOT NULL,
  `key` varchar(30) NOT NULL,
  `rate` float DEFAULT '0',
  `flag` int(5) DEFAULT '0',
  PRIMARY KEY (`id`),
  foreign KEY (`participant`) references participants(email)
) ;


--
-- Table structure for table `facilitators`
--

DROP TABLE IF EXISTS `facilitators`;
CREATE TABLE IF NOT EXISTS `facilitators` (
  `fname` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `femail` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fpassword` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ftelephone` int(11) NOT NULL,
  PRIMARY KEY (`femail`)
);

--
-- Table structure for table `participants`
--

DROP TABLE IF EXISTS `participants`;
CREATE TABLE IF NOT EXISTS `participants` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` int(11) NOT NULL,
  `flag` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email`)
);


-- Table structure for table `pending`
--

DROP TABLE IF EXISTS `pending`;
CREATE TABLE IF NOT EXISTS `pending` (
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `telephone` int(10) NOT NULL,
  `type` varchar(30) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`email`)
);

-- --------------------------------------------------------

--
-- Table structure for table `rated`
--

DROP TABLE IF EXISTS `rated`;
CREATE TABLE IF NOT EXISTS `rated` (
  `answerid` int(100) NOT NULL,
  `key` varchar(30) NOT NULL,
  `participant` varchar(30) NOT NULL,
  `rate` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`answerid`)
);

--
-- Table structure for table `rounds`
--

DROP TABLE IF EXISTS `rounds`;
CREATE TABLE IF NOT EXISTS `rounds` (
  `participant` varchar(30) NOT NULL,
  `key` varchar(30) NOT NULL,
  `1` int(5) NOT NULL DEFAULT '0',
  `2` int(5) NOT NULL DEFAULT '0',
  `3` int(5) NOT NULL DEFAULT '0',
  `4` int(5) NOT NULL DEFAULT '0',
  `5` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`participant`)
); 

--
-- Table structure for table `workshop`
--

DROP TABLE IF EXISTS `workshop`;
CREATE TABLE IF NOT EXISTS `workshop` (
  `name` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `facilitator` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `participantsnb` int(11) NOT NULL,
  PRIMARY KEY (`key`),
   foreign KEY (`facilitator`) references facilitators(email)
);

